lista=[]
lista=input("Introduce 6 numeros separados por -: ")
lista=lista.split('-')
#lista=lista.float(lista)
listam=max(lista)
listamin=min(lista)
#promedio=sum(lista)//6
print(f"Máximo: {listam}")
print(f"Mínimo: {listamin}")
#print(f"Promedio: {promedio}")